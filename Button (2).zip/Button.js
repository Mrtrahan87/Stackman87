console.log("page loaded...");

function message() {
    alert("Ninja was liked!!");
}

function message() {
    alert('Ninja was SUPER LIKED');
}

function login(element) {
    if(element.innerText== "login") {
        element.innerText= "logout";
    } else{
        element.innerText= "login";
    }

}

function hide(el) {
    el.remove();
}